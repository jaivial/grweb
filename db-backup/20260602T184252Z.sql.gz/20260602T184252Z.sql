-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: grcup
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Athletes`
--

DROP TABLE IF EXISTS `Athletes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Athletes` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `FirstName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Surname` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Phone` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Sex` int NOT NULL,
  `WeightCategory` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Club` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `TotalWeight` decimal(10,2) DEFAULT NULL,
  `RegistrationDate` datetime(6) NOT NULL,
  `Coach` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Status` int NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `CheckinAt` datetime(6) DEFAULT NULL,
  `QrCode` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  PRIMARY KEY (`Id`),
  KEY `IX_Athletes_Email` (`Email`),
  KEY `IX_Athletes_Sex` (`Sex`),
  KEY `IX_Athletes_Status` (`Status`),
  KEY `IX_Athletes_WeightCategory` (`WeightCategory`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Athletes`
--

LOCK TABLES `Athletes` WRITE;
/*!40000 ALTER TABLE `Athletes` DISABLE KEYS */;
/*!40000 ALTER TABLE `Athletes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CodigosReferido`
--

DROP TABLE IF EXISTS `CodigosReferido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CodigosReferido` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `InscripcionId` int NOT NULL,
  `CompeticionId` int NOT NULL,
  `Codigo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CodigoNormalizado` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_CodigosReferido_InscripcionId` (`InscripcionId`),
  UNIQUE KEY `IX_CodigosReferido_CompeticionId_CodigoNormalizado` (`CompeticionId`,`CodigoNormalizado`),
  KEY `IX_CodigosReferido_CompeticionId` (`CompeticionId`),
  CONSTRAINT `FK_CodigosReferido_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_CodigosReferido_Inscripciones_InscripcionId` FOREIGN KEY (`InscripcionId`) REFERENCES `Inscripciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CodigosReferido`
--

LOCK TABLES `CodigosReferido` WRITE;
/*!40000 ALTER TABLE `CodigosReferido` DISABLE KEYS */;
INSERT INTO `CodigosReferido` VALUES (1,28,2,'ALXXABGR','ALXXABGR','2026-06-01 15:22:56.680325','2026-06-01 15:22:56.680359'),(2,44,2,'AIXXAIGR','AIXXAIGR','2026-06-01 15:22:56.844256','2026-06-01 15:22:56.844256'),(3,48,2,'ALXXALGR','ALXXALGR','2026-06-01 15:22:56.850241','2026-06-01 15:22:56.850241'),(4,29,2,'ANXXANGR','ANXXANGR','2026-06-01 15:22:56.854348','2026-06-01 15:22:56.854348'),(5,45,2,'ANXXANGRRALX','ANXXANGRRALX','2026-06-01 15:22:56.861048','2026-06-01 15:22:56.861048'),(6,35,2,'ÁNXXENGR','ÁNXXENGR','2026-06-01 15:22:56.865181','2026-06-01 15:22:56.865181'),(7,43,2,'ENXXENGR','ENXXENGR','2026-06-01 15:22:56.869146','2026-06-01 15:22:56.869147'),(8,27,2,'FEXXFEGR','FEXXFEGR','2026-06-01 15:22:56.872963','2026-06-01 15:22:56.872963'),(9,38,2,'MAXXHEGR','MAXXHEGR','2026-06-01 15:22:56.876720','2026-06-01 15:22:56.876720'),(10,42,2,'IKXXKOGR','IKXXKOGR','2026-06-01 15:22:56.880508','2026-06-01 15:22:56.880508'),(11,37,2,'LAXXLAGR','LAXXLAGR','2026-06-01 15:22:56.884434','2026-06-01 15:22:56.884434'),(12,47,2,'LUXXLUGR','LUXXLUGR','2026-06-01 15:22:56.888339','2026-06-01 15:22:56.888339'),(13,41,2,'MAXXMAGR','MAXXMAGR','2026-06-01 15:22:56.892306','2026-06-01 15:22:56.892306'),(14,34,2,'MAXXMAGRSGIF','MAXXMAGRSGIF','2026-06-01 15:22:56.897200','2026-06-01 15:22:56.897200'),(15,36,2,'MAXXMAGRSIEM','MAXXMAGRSIEM','2026-06-01 15:22:56.902317','2026-06-01 15:22:56.902317'),(16,32,2,'MAXXMAGRW8LK','MAXXMAGRW8LK','2026-06-01 15:22:56.908257','2026-06-01 15:22:56.908257'),(17,26,2,'MIXXMIGR','MIXXMIGR','2026-06-01 15:22:56.912204','2026-06-01 15:22:56.912204'),(18,33,2,'REXXREGR','REXXREGR','2026-06-01 15:22:56.916344','2026-06-01 15:22:56.916344'),(19,30,2,'REXXREGR0B2F','REXXREGR0B2F','2026-06-01 15:22:56.921580','2026-06-01 15:22:56.921580'),(20,46,2,'SHXXSHGR','SHXXSHGR','2026-06-01 15:22:56.925813','2026-06-01 15:22:56.925813'),(21,49,2,'DAXXDAGR','DAXXDAGR','2026-06-01 15:54:53.389709','2026-06-01 15:54:53.389743'),(22,50,2,'PAXXPAGR','PAXXPAGR','2026-06-01 18:06:39.939753','2026-06-01 18:06:39.939753'),(23,51,2,'RUXXRUGR','RUXXRUGR','2026-06-01 19:11:03.846218','2026-06-01 19:11:03.846218'),(24,52,2,'JUXXJUGR','JUXXJUGR','2026-06-01 19:55:27.131854','2026-06-01 19:55:27.131854'),(25,53,2,'TOXXTOGR','TOXXTOGR','2026-06-01 21:52:13.705002','2026-06-01 21:52:13.705002'),(26,54,2,'ANXXNEGR','ANXXNEGR','2026-06-02 04:29:08.455770','2026-06-02 04:29:08.455770'),(27,55,2,'RAXXRAGR','RAXXRAGR','2026-06-02 05:48:39.242464','2026-06-02 05:48:39.242464'),(28,56,2,'JUXXROGR','JUXXROGR','2026-06-02 14:43:18.209369','2026-06-02 14:43:18.209369'),(29,57,2,'MAXXMAGRWXB4','MAXXMAGRWXB4','2026-06-02 16:22:44.521255','2026-06-02 16:22:44.521255'),(30,58,2,'JEXXJEGR','JEXXJEGR','2026-06-02 17:19:19.866377','2026-06-02 17:19:19.866377');
/*!40000 ALTER TABLE `CodigosReferido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Competiciones`
--

DROP TABLE IF EXISTS `Competiciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Competiciones` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Fecha` datetime(6) NOT NULL,
  `Lugar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Activo` tinyint(1) NOT NULL,
  `LogoUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `FaviconUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `LandingConfig` json DEFAULT NULL,
  `EventoConfig` json DEFAULT NULL,
  `QrSecret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Tipo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `Descripcion` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `EmailContacto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Telefono` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `HorariosReady` tinyint(1) NOT NULL DEFAULT '0',
  `ModulesConfig` json DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Competiciones_Slug` (`Slug`),
  KEY `IX_Competiciones_Activo` (`Activo`),
  KEY `IX_Competiciones_Tipo` (`Tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Competiciones`
--

LOCK TABLES `Competiciones` WRITE;
/*!40000 ALTER TABLE `Competiciones` DISABLE KEYS */;
INSERT INTO `Competiciones` VALUES (1,'GR Cup 2026','grcup','2026-07-25 00:00:00.000000','Almussafes, Valencia',1,NULL,NULL,'{\"LogoUrl\": null, \"Descripcion\": \"La competición de powerlifting más esperada del año\", \"ContactEmail\": null, \"HeroImageUrl\": null, \"InstagramUrl\": null, \"PrimaryColor\": \"#DC2626\", \"SecondaryColor\": \"#991B1B\"}','{\"PrecioBase\": 35, \"PrecioRifa\": 5, \"AforoMaximo\": 100, \"PrecioHandler\": 0, \"StripePriceId\": null, \"PrecioPeakProgram\": 0, \"InscripcionAbierta\": true, \"MaxTicketsPorPersona\": 10, \"FechaLimitePeakProgram\": null}','Z3JjdXAtNjM5MTQ2Mzc2NjA5MzE5MTYwLTQ1ZDE2NWM0LTlhN2EtNDg3Yi05M2I2LWM1OWIwZDQxNGM0NQ','grcup','2026-05-17 18:01:00.931301','2026-05-17 18:01:00.931301','La competición de powerlifting más esperada del año','admin@grstrength.com','+34 600 000 001',0,NULL),(2,'FER CUP II','fer','2026-07-25 00:00:00.000000','Almussafes, Valencia',1,NULL,NULL,'{\"LogoUrl\": null, \"Descripcion\": \"Tu primera competición de Powerlifting\", \"ContactEmail\": null, \"HeroImageUrl\": null, \"InstagramUrl\": \"https://instagram.com/ferentrenamiento\", \"PrimaryColor\": \"#3B82F6\", \"SecondaryColor\": \"#60A5FA\"}','{\"PrecioBase\": 35, \"PrecioRifa\": 5, \"AforoMaximo\": 50, \"PrecioHandler\": 0, \"StripePriceId\": null, \"ReferidosActivo\": true, \"PagoStripeActivo\": true, \"PrecioPeakProgram\": 30, \"InscripcionAbierta\": true, \"PagoEfectivoActivo\": false, \"MaxTicketsPorPersona\": 5, \"CuponesDescuentoActivo\": true, \"FechaLimitePeakProgram\": \"2026-07-04\"}','ZmVyLTYzOTE0NjM3NjYxMDk4NTU1My1iNDE2OGNmNy0zMDEzLTRhZTAtOTVjOC1lYWE4NDU3ZDYzNWM','fer','2026-05-17 18:01:01.098554','2026-06-01 16:01:24.638856','FER CUP II: tu primera competición de powerlifting en un ambiente profesional y acogedor','info@ferentrenamiento.com','+34 600 000 000',0,NULL);
/*!40000 ALTER TABLE `Competiciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CuponesDescuento`
--

DROP TABLE IF EXISTS `CuponesDescuento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CuponesDescuento` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CompeticionId` int NOT NULL,
  `Codigo` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CodigoNormalizado` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TipoDescuento` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Valor` decimal(10,2) NOT NULL,
  `Activo` tinyint(1) NOT NULL,
  `TieneLimiteUsos` tinyint(1) NOT NULL,
  `LimiteUsos` int DEFAULT NULL,
  `TieneFechaExpiracion` tinyint(1) NOT NULL,
  `FechaExpiracion` datetime(6) DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_CuponesDescuento_CompeticionId_CodigoNormalizado` (`CompeticionId`,`CodigoNormalizado`),
  KEY `IX_CuponesDescuento_Activo` (`Activo`),
  CONSTRAINT `FK_CuponesDescuento_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CuponesDescuento`
--

LOCK TABLES `CuponesDescuento` WRITE;
/*!40000 ALTER TABLE `CuponesDescuento` DISABLE KEYS */;
/*!40000 ALTER TABLE `CuponesDescuento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Draws`
--

DROP TABLE IF EXISTS `Draws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Draws` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `WinnerEmail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `WinnerName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `WinnerInstagram` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `WinnerTicketCount` int DEFAULT NULL,
  `DrawDate` datetime(6) NOT NULL,
  `Notes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `IsConfirmed` tinyint(1) NOT NULL,
  `ParticipantId` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Draws_ParticipantId` (`ParticipantId`),
  CONSTRAINT `FK_Draws_Participants_ParticipantId` FOREIGN KEY (`ParticipantId`) REFERENCES `Participants` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Draws`
--

LOCK TABLES `Draws` WRITE;
/*!40000 ALTER TABLE `Draws` DISABLE KEYS */;
/*!40000 ALTER TABLE `Draws` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmailConfig`
--

DROP TABLE IF EXISTS `EmailConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EmailConfig` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MainProvider` int NOT NULL,
  `GmailAddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `GmailAppPassword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SmtpUsername` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SmtpPassword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SmtpEmailAddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SmtpHost` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SmtpPort` int NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `CompeticionId` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_EmailConfig_CompeticionId` (`CompeticionId`),
  CONSTRAINT `FK_EmailConfig_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmailConfig`
--

LOCK TABLES `EmailConfig` WRITE;
/*!40000 ALTER TABLE `EmailConfig` DISABLE KEYS */;
INSERT INTO `EmailConfig` VALUES (1,1,'nicogorra14@gmail.com','xbqo mxtb dcsm ezzs',NULL,NULL,NULL,NULL,0,'2026-05-17 22:01:00.970993','2026-05-17 22:01:00.971045',2);
/*!40000 ALTER TABLE `EmailConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InscripcionConfig`
--

DROP TABLE IF EXISTS `InscripcionConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InscripcionConfig` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CreatedAt` datetime(6) NOT NULL,
  `EditedAt` datetime(6) NOT NULL,
  `Active` tinyint(1) NOT NULL,
  `Url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InscripcionConfig`
--

LOCK TABLES `InscripcionConfig` WRITE;
/*!40000 ALTER TABLE `InscripcionConfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `InscripcionConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Inscripciones`
--

DROP TABLE IF EXISTS `Inscripciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Inscripciones` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CompeticionId` int NOT NULL,
  `Nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Instagram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Experiencia` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TieneEntrenador` tinyint(1) NOT NULL,
  `QrCode` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PagoConfirmado` tinyint(1) NOT NULL,
  `PaymentMethod` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `TotalPagado` decimal(10,2) NOT NULL,
  `CheckinAt` datetime(6) DEFAULT NULL,
  `AceptaTerminos` tinyint(1) NOT NULL,
  `Notas` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `CategoriaPeso` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `ParticipacionConfirmada` tinyint(1) NOT NULL DEFAULT '0',
  `QuiereHandler` tinyint(1) NOT NULL DEFAULT '0',
  `Sexo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `Telefono` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `QuierePeakProgram` tinyint(1) NOT NULL DEFAULT '0',
  `Modalidad` varchar(30) NOT NULL DEFAULT 'completa',
  `StripeSessionId` varchar(255) DEFAULT NULL,
  `CuponDescuentoId` int DEFAULT NULL,
  `CodigoCupon` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `TipoDescuentoCupon` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ValorDescuentoCupon` decimal(10,2) DEFAULT NULL,
  `SubtotalAntesDescuento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ImporteDescuento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Apellido1` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Apellido2` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `StripePaymentIntentId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ReferralCodeId` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Inscripciones_CompeticionId_Email` (`CompeticionId`,`Email`),
  KEY `IX_Inscripciones_Email` (`Email`),
  KEY `IX_Inscripciones_PagoConfirmado` (`PagoConfirmado`),
  KEY `IX_Inscripciones_Modalidad` (`Modalidad`),
  KEY `IX_Inscripciones_StripeSessionId` (`StripeSessionId`),
  KEY `IX_Inscripciones_CuponDescuentoId` (`CuponDescuentoId`),
  KEY `IX_Inscripciones_ReferralCodeId` (`ReferralCodeId`),
  KEY `IX_Inscripciones_StripePaymentIntentId` (`StripePaymentIntentId`),
  CONSTRAINT `FK_Inscripciones_CodigosReferido_ReferralCodeId` FOREIGN KEY (`ReferralCodeId`) REFERENCES `CodigosReferido` (`Id`) ON DELETE SET NULL,
  CONSTRAINT `FK_Inscripciones_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Inscripciones_CuponesDescuento_CuponDescuentoId` FOREIGN KEY (`CuponDescuentoId`) REFERENCES `CuponesDescuento` (`Id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Inscripciones`
--

LOCK TABLES `Inscripciones` WRITE;
/*!40000 ALTER TABLE `Inscripciones` DISABLE KEYS */;
INSERT INTO `Inscripciones` VALUES (26,2,'Miguel Andreu Grimaldo Rodríguez','miguelandreug@gmail.com','Miguellift','avanzado',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_26.png',1,'cupon',0.00,NULL,1,NULL,'2026-05-25 22:07:49.046277','2026-05-25 22:07:49.046277','-105',0,0,'masculino','653378700',0,'solo_banca',NULL,NULL,NULL,NULL,NULL,0.00,0.00,NULL,NULL,NULL,NULL),(27,2,'Fernando Ripoll Valero','ferrv.21@gmail.com','fernanndoripoll','principiante',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_27.png',1,'cupon',0.00,NULL,1,NULL,'2026-05-25 22:37:26.056113','2026-05-25 22:37:26.056114','-74',0,1,'masculino','+34603895800',0,'completa',NULL,NULL,NULL,NULL,NULL,0.00,0.00,NULL,NULL,NULL,NULL),(28,2,'Alberto Badia Benllcoh','abadiabenlloch@gmail.com','alber_badia_','principiante',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_28.png',1,'stripe',35.00,NULL,1,NULL,'2026-05-26 04:05:32.608239','2026-05-26 04:05:32.608239','-93',0,0,'masculino','659124895',0,'completa','cs_live_a1RBysww1mTcbZEoiO0D26v2y1yy0kb79Fn8Mon3apjU9dPC99VNf5TcH8',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(29,2,'Ana Martorell Nevot','anaapuntesveterinaria@gmail.com','Anmart_','rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_29.png',1,'stripe',35.00,NULL,1,'Necesita HANDLER\nNos lo confirma por IG / Mail','2026-05-26 07:03:49.520397','2026-05-26 09:53:21.590850','-47',0,1,'femenino','671940952',0,'completa','cs_live_a1ZLqD79w7tpOEKXYTP253wBdd3j5zyoyOQuCLJtmlzOUecH9HKmkxjpv5',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(30,2,'Remedios Martinez Iborra','remedios.romani@gmail.com','reme_romani','principiante',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_30.png',1,'stripe',15.00,NULL,1,NULL,'2026-05-26 10:04:45.495075','2026-05-26 10:04:45.495075','-63',0,1,'femenino','609854409',0,'solo_banca','cs_live_a1IjzEY5Fq7XMYRtDiH4O9uKT6Mt4nLj6kbWUVo7gbnUVazYIJ1IB91h1Q',NULL,NULL,NULL,NULL,15.00,0.00,NULL,NULL,NULL,NULL),(32,2,'Mayte Valiente Bonafé','maytevaliente@gmail.com','maytevalbon','avanzado',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_32.png',1,'cupon',0.00,NULL,1,NULL,'2026-05-26 10:29:47.879915','2026-05-26 10:29:47.879915','-63',0,0,'femenino','+34666343427',0,'completa',NULL,NULL,NULL,NULL,NULL,0.00,0.00,NULL,NULL,NULL,NULL),(33,2,'Rebeca Casanova Pastor','rebecasanovap@gmail.com',NULL,'rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_33.png',1,'stripe',35.00,NULL,1,NULL,'2026-05-26 13:40:16.043847','2026-05-26 13:40:16.043848','-76',0,0,'femenino','610606201',0,'completa','cs_live_a1DPNEy71opsuJnQkQBMttZcDOJ7NmyhZWPJQdh3cdRYhmmyf9sOgDZ6RQ',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(34,2,'Margaret Ivelinova Stoyneva','margaretstoy@icloud.com',NULL,'rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_34.png',1,'stripe',35.00,NULL,1,NULL,'2026-05-26 19:30:57.001475','2026-05-26 19:30:57.001475','-69',0,0,'femenino','0034641612696',0,'completa','cs_live_a14bLm3ATjSpHaAKphw2bRjsqxO84rr6BmetOZ8Hb7psRtLcQZk0afPYJP',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(35,2,'Ángel Rubio','enelcurro1@gmail.com',NULL,'rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_35.png',1,'stripe',35.00,NULL,1,NULL,'2026-05-27 08:30:25.139105','2026-05-27 08:30:25.139105','-74',0,1,'masculino','675567487',0,'completa','cs_live_a1DEt6TPP9zTAZEjXQiqJOApjWlNHJwg8kQi17vR26SQgBDyUlZxVZCFhb',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(36,2,'Marta Gómez Álvarez','martagoal28@gmail.com','glomokito_','avanzado',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_36.png',1,'stripe',15.00,NULL,1,NULL,'2026-05-27 09:30:01.955910','2026-05-27 09:30:01.955911','-63',0,1,'femenino','646246975',0,'completa','cs_live_a16YYQXRAzrREEmE7rlaYD3gPu7h2QScdeHmTyL9RcWroR21RVHbAN04tt',NULL,NULL,NULL,NULL,15.00,0.00,NULL,NULL,NULL,NULL),(37,2,'laura sofia aguilar albarracin','laurasofiaaguilaralbarracin072@gmail.com','laurasofia022','principiante',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_37.png',1,'stripe',35.00,NULL,1,NULL,'2026-05-27 21:29:19.709988','2026-05-27 21:29:19.709988','-57',0,0,'femenino','+34602048741',0,'completa','cs_live_a1IMkpeiESquVMzOflo0vSE1t8J2pY3xgF3r57TNihXmvdL3bWDZyUVOfH',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(38,2,'Marta Roca Doblado','hey.mortyy@gmail.com','Tuuktuuk_','avanzado',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_38.png',1,'stripe',15.00,NULL,1,NULL,'2026-05-28 16:34:21.416768','2026-05-28 16:34:21.416768','-76',0,0,'femenino','649235096',0,'completa','cs_live_a1mVRSGxeys6de1NB2YUcW4ZDQu2ABbBNoH7BXZRhqAnnUTsNU7F0ghFoX',NULL,NULL,NULL,NULL,15.00,0.00,NULL,NULL,NULL,NULL),(41,2,'Marcos Herrera','marcosherrera1345@gmail.com','marcs_herrera','rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_41.png',1,'stripe',35.00,NULL,1,NULL,'2026-05-30 15:15:11.458536','2026-05-30 15:15:11.458537','-93',0,0,'masculino','696918006',0,'completa','cs_live_a1HbscC3LV3ZxhKYewFQ59KO5P9dGUVEkGZ3u4XMrz2BKCx4FYOKIYtQzO',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(42,2,'Iker Ibañez Alvarez','kolpyui2@gmail.com','iker__vlc','rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_42.png',1,'stripe',35.00,NULL,1,NULL,'2026-05-31 16:13:39.361706','2026-05-31 16:13:39.361706','-120',0,0,'masculino','722322997',0,'completa','cs_live_a1vI1foQROJ0tlQsox5qKcorT5vaAGTQ7ivwwvLca6HHfWjf2QDxixvJPd',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(43,2,'Enzo Rodenas','enzorodenass@gmail.com','enzoorodenas','intermedio',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_43.png',1,'stripe',35.00,NULL,1,NULL,'2026-05-31 16:13:44.283301','2026-05-31 16:13:44.283301','-74',0,0,'masculino','684328111',0,'completa','cs_live_a1avtTR9Pxj8pYwigWL4joSQlbTpNcyYAnvn56vEitBvLkIgsPLMCCb6hN',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(44,2,'Ainara Arencibia López','ainaraarencibialope@gmail.com','Stranger_ainara','avanzado',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_44.png',1,'cupon',0.00,NULL,1,NULL,'2026-05-31 19:30:49.115278','2026-05-31 19:30:49.115278','+84',0,0,'femenino','+34605382243',0,'completa',NULL,NULL,NULL,NULL,NULL,0.00,0.00,NULL,NULL,NULL,NULL),(45,2,'Antonio Corella Arbona','antocoar87@gmail.com','antonioo_sbd','principiante',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_45.png',1,'stripe',35.00,NULL,1,NULL,'2026-05-31 20:33:36.938234','2026-05-31 20:33:36.938234','-83',0,0,'masculino','+34 641 89 50 51',0,'completa','cs_live_a1KhHvgruWfbI73HnKbZHdYvdiyzSAAelWYm0daIm7FzQkT3WuptrpOiWy',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(46,2,'Shakira Quesada Mares','shakiraquesama@gmail.com','shakiraquesada_','rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_46.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-01 06:58:11.459397','2026-06-01 06:58:11.459397','-63',0,1,'femenino','611458755',0,'completa','cs_live_a17e655Ar79wLAA4mOCpXlIJr3UabKneghCAhZDPobJJYTRK1dUSfnIfas',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(47,2,'Luis Arturo López Gonzalez','luis.lg96@icloud.com',NULL,'principiante',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_47.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-01 09:37:25.393077','2026-06-01 09:37:25.393077','-83',0,0,'masculino','+34684081622',0,'completa','cs_live_a13jNsazFvRLd8tgMw9AOXAUw2jUMgNL0GM85iUyVSWzvDzkmsJQQMI6Xp',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(48,2,'Alejandro Gómez de Luna Conesa','alexgomezdeluna7@gmail.com','Alex.fisiopower','intermedio',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_48.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-01 09:39:49.187399','2026-06-01 09:39:49.187399','-83',0,1,'masculino','660178838',0,'completa','cs_live_a1C8TLrNwpS2e7FogyEaiH9GEjGohXuO0TFnoLj9uvCA71DQjUDR4rvPRs',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,NULL,NULL),(49,2,'Daniel Gómez','danidanette222001@gmail.com','_danette22','intermedio',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_49.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-01 15:54:52.557769','2026-06-01 15:54:53.409188','-83',0,1,'masculino','603814514',0,'completa','cs_live_a1WU9DkkEnZYEK61l9juhqw84XCb97JGTlMgN3caSkpiQLM1btGBJcr7Gp',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3TdYAwRiba9vq0000DCg35EN',NULL),(50,2,'Pau Alexandre Meseguer Cárceles','paumesseguerc@gmail.com',NULL,'intermedio',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_50.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-01 18:06:39.801834','2026-06-01 18:06:39.942046','-120',0,1,'masculino','+34671626529',0,'completa','cs_live_a1CMsGc8DPRXcHTegSvpAYN3om2yLFS77QyiksQuhAIm7dYP80JS0mqnTi',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3TdaERRiba9vq0000prI401C',NULL),(51,2,'Ruben Calabuig Fenollosa','rubencalabuig9@gmail.con',NULL,'rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_51.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-01 19:11:03.506329','2026-06-01 19:11:03.848583','-83',0,0,'masculino','687291493',0,'completa','cs_live_a193tAIkvBzD1l4cvtWC2jbJfoXOk1CBrrgNYAZam9M3i0ebZ54et8ugSp',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3TdbEkRiba9vq0001d07T38d',NULL),(52,2,'Juan Pelayo Martínez','juanpm0619@gmail.com','juanpm0619','intermedio',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_52.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-01 19:55:26.971967','2026-06-01 19:55:27.134300','-93',0,1,'masculino','+34662468273',0,'solo_banca','cs_live_a1XPJC9PDMn4HpYxjF5nyz7SIZkpnnS0c8z2eBhLoPW0b0DpYMarqsTvnm',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3TdbvfRiba9vq0000Thtxd08',NULL),(53,2,'Tomás Álvarez','tomas.alvarezrobles@icloud.com',NULL,'rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_53.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-01 21:52:13.575018','2026-06-01 21:52:13.707328','-83',0,1,'masculino','648076481',0,'completa','cs_live_a1cckep7o3OF5IxqkYaVIlw0B9kBbBFOxhPgKEzwQIVe7Zxs2flTG6Fcdn',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3TddkjRiba9vq0001oupZYE2',NULL),(54,2,'Ane Salsidua Arroyo','netxu96@gmail.com','Aneetxuu96','principiante',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_54.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-02 04:29:08.331575','2026-06-02 04:29:08.457822','-63',0,0,'femenino','664785332',0,'completa','cs_live_a1b89Gs86nH8Mg8qhCneIIT49TpWKl968NT6OFCWmQu6300wnGik9Mfwx3',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3TdjwpRiba9vq0001bsL0nR3',NULL),(55,2,'Raúl Novella Martínez','raul.novella.2005@gmail.com','_raulnm_','rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_55.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-02 05:48:39.121071','2026-06-02 05:48:39.244301','-93',0,1,'masculino','+34 608 33 59 44',0,'solo_banca','cs_live_a1R6p64hatA70TPJ1zTiRm4OohKkaNh3i3KNRM2mcyhlyUpk3DPf7xo5OG',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3TdlBoRiba9vq00018ioolGj',NULL),(56,2,'Juan Rodrigo Tello Gómez','rodrigotellogomez@gmail.com','rodrigotelo_','intermedio',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_56.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-02 14:43:18.069428','2026-06-02 14:43:18.211162','-66',0,1,'masculino','+34644833710',0,'completa','cs_live_a1mM9NxOlm2MS7zCOTOM2aWbio6oodfkgW6tMVbBM1r2pYR3B8WTdumLl2',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3TdtXCRiba9vq0001t4pVQeX',NULL),(57,2,'Marcos López Blay','marcosblay@hotmail.com',NULL,'rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_57.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-02 16:22:44.294276','2026-06-02 16:22:44.523615','-105',0,1,'masculino','+34664353307',0,'completa','cs_live_a15F4MtbSPOPizzuzXvYBLPDOWjPeCYnUe0Xa26KLMJPyDhQLje2wemHll',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3Tdv5RRiba9vq0001vnyyNTJ',NULL),(58,2,'Jean piero Herrera Arizola','jeanpierrr20@gmail.com','@jeanpiero_herrera','rookie',0,'https://jaimedigitalstudio.b-cdn.net/grcup/qr/2/qr_2_58.png',1,'stripe',35.00,NULL,1,NULL,'2026-06-02 17:19:19.610494','2026-06-02 17:19:19.867863','-83',0,0,'masculino','+34632630979',0,'completa','cs_live_a11wnACxfuEta7JIyp1mdi3eoGq1E0z0GxpAcfuqAgGfJqghiTxb1YuagH',NULL,NULL,NULL,NULL,35.00,0.00,NULL,NULL,'pi_3TdvyARiba9vq0001TapwebQ',NULL);
/*!40000 ALTER TABLE `Inscripciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InscripcionesPreparadas`
--

DROP TABLE IF EXISTS `InscripcionesPreparadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InscripcionesPreparadas` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `DateTime` datetime(6) DEFAULT NULL,
  `Preparadas` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InscripcionesPreparadas`
--

LOCK TABLES `InscripcionesPreparadas` WRITE;
/*!40000 ALTER TABLE `InscripcionesPreparadas` DISABLE KEYS */;
INSERT INTO `InscripcionesPreparadas` VALUES (1,NULL,0);
/*!40000 ALTER TABLE `InscripcionesPreparadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LiftEntries`
--

DROP TABLE IF EXISTS `LiftEntries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LiftEntries` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `AthleteId` int NOT NULL,
  `LiftType` int NOT NULL,
  `AttemptNumber` int NOT NULL,
  `Weight` decimal(10,2) NOT NULL,
  `UpdatedBy` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_LiftEntries_AthleteId_LiftType_AttemptNumber` (`AthleteId`,`LiftType`,`AttemptNumber`),
  KEY `IX_LiftEntries_AthleteId` (`AthleteId`),
  CONSTRAINT `FK_LiftEntries_Athletes_AthleteId` FOREIGN KEY (`AthleteId`) REFERENCES `Athletes` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LiftEntries`
--

LOCK TABLES `LiftEntries` WRITE;
/*!40000 ALTER TABLE `LiftEntries` DISABLE KEYS */;
/*!40000 ALTER TABLE `LiftEntries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LiftEntriesInscripcion`
--

DROP TABLE IF EXISTS `LiftEntriesInscripcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LiftEntriesInscripcion` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `InscripcionId` int NOT NULL,
  `LiftType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `AttemptNumber` int NOT NULL,
  `Weight` decimal(6,2) NOT NULL,
  `UpdatedBy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `Juez1Voto` tinyint(1) DEFAULT NULL,
  `Juez2Voto` tinyint(1) DEFAULT NULL,
  `Juez3Voto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_LiftEntriesInscripcion_InscripcionId_LiftType_AttemptNumber` (`InscripcionId`,`LiftType`,`AttemptNumber`),
  KEY `IX_LiftEntriesInscripcion_InscripcionId` (`InscripcionId`),
  CONSTRAINT `FK_LiftEntriesInscripcion_Inscripciones_InscripcionId` FOREIGN KEY (`InscripcionId`) REFERENCES `Inscripciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LiftEntriesInscripcion`
--

LOCK TABLES `LiftEntriesInscripcion` WRITE;
/*!40000 ALTER TABLE `LiftEntriesInscripcion` DISABLE KEYS */;
/*!40000 ALTER TABLE `LiftEntriesInscripcion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NewUserReferrals`
--

DROP TABLE IF EXISTS `NewUserReferrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NewUserReferrals` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CodigoReferidoId` int NOT NULL,
  `InscripcionId` int NOT NULL,
  `TipoDescuento` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ImporteDescuento` decimal(10,2) NOT NULL,
  `VecesUsado` int NOT NULL,
  `ImporteAcumuladoReferente` decimal(10,2) NOT NULL,
  `StripeRefundId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `RefundedAt` datetime(6) DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_NewUserReferrals_InscripcionId` (`InscripcionId`),
  UNIQUE KEY `IX_NewUserReferrals_CodigoReferidoId_InscripcionId` (`CodigoReferidoId`,`InscripcionId`),
  CONSTRAINT `FK_NewUserReferrals_CodigosReferido_CodigoReferidoId` FOREIGN KEY (`CodigoReferidoId`) REFERENCES `CodigosReferido` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_NewUserReferrals_Inscripciones_InscripcionId` FOREIGN KEY (`InscripcionId`) REFERENCES `Inscripciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NewUserReferrals`
--

LOCK TABLES `NewUserReferrals` WRITE;
/*!40000 ALTER TABLE `NewUserReferrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `NewUserReferrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Participants`
--

DROP TABLE IF EXISTS `Participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Participants` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `FirstName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Surname` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Instagram` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TicketCount` int NOT NULL,
  `TotalPaid` decimal(10,2) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `Phone` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Price` decimal(65,30) DEFAULT NULL,
  `IsPaid` tinyint(1) NOT NULL DEFAULT '1',
  `PaymentMethod` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `DateModified` datetime(6) DEFAULT NULL,
  `StripeSessionId` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Participants_Email` (`Email`),
  KEY `IX_Participants_Email_PaymentMethod_IsPaid` (`Email`,`PaymentMethod`,`IsPaid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Participants`
--

LOCK TABLES `Participants` WRITE;
/*!40000 ALTER TABLE `Participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `Participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RaffleProducts`
--

DROP TABLE IF EXISTS `RaffleProducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RaffleProducts` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `Title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Subtitle` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `DisplayOrder` int NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `ImageUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_RaffleProducts_DisplayOrder` (`DisplayOrder`),
  KEY `IX_RaffleProducts_IsActive` (`IsActive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RaffleProducts`
--

LOCK TABLES `RaffleProducts` WRITE;
/*!40000 ALTER TABLE `RaffleProducts` DISABLE KEYS */;
/*!40000 ALTER TABLE `RaffleProducts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReferidosConfig`
--

DROP TABLE IF EXISTS `ReferidosConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ReferidosConfig` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CompeticionId` int NOT NULL,
  `Activo` tinyint(1) NOT NULL,
  `Modo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TipoDescuentoReferente` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ValorDescuentoReferente` decimal(10,2) NOT NULL,
  `TieneLimiteUsos` tinyint(1) NOT NULL,
  `LimiteUsos` int DEFAULT NULL,
  `ModoAcumulativo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `MultiplicadorAcumulativo` decimal(10,2) DEFAULT NULL,
  `TipoDescuentoNuevoUsuario` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ValorDescuentoNuevoUsuario` decimal(10,2) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_ReferidosConfig_CompeticionId` (`CompeticionId`),
  CONSTRAINT `FK_ReferidosConfig_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReferidosConfig`
--

LOCK TABLES `ReferidosConfig` WRITE;
/*!40000 ALTER TABLE `ReferidosConfig` DISABLE KEYS */;
INSERT INTO `ReferidosConfig` VALUES (1,1,0,'basico','importe',0.00,0,NULL,NULL,NULL,'porcentaje',0.00,'2026-06-01 14:25:21.625756','2026-06-01 14:25:21.625756'),(2,2,0,'basico','importe',0.00,0,NULL,NULL,NULL,'porcentaje',0.00,'2026-06-01 14:25:21.625756','2026-06-01 14:25:21.625756');
/*!40000 ALTER TABLE `ReferidosConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReferidosUserSetting`
--

DROP TABLE IF EXISTS `ReferidosUserSetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ReferidosUserSetting` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CodigoReferidoId` int NOT NULL,
  `Activo` tinyint(1) NOT NULL,
  `Modo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TipoDescuentoReferente` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ValorDescuentoReferente` decimal(10,2) NOT NULL,
  `TieneLimiteUsos` tinyint(1) NOT NULL,
  `LimiteUsos` int DEFAULT NULL,
  `ModoAcumulativo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `MultiplicadorAcumulativo` decimal(10,2) DEFAULT NULL,
  `TipoDescuentoNuevoUsuario` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ValorDescuentoNuevoUsuario` decimal(10,2) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_ReferidosUserSetting_CodigoReferidoId` (`CodigoReferidoId`),
  CONSTRAINT `FK_ReferidosUserSetting_CodigosReferido_CodigoReferidoId` FOREIGN KEY (`CodigoReferidoId`) REFERENCES `CodigosReferido` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReferidosUserSetting`
--

LOCK TABLES `ReferidosUserSetting` WRITE;
/*!40000 ALTER TABLE `ReferidosUserSetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReferidosUserSetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResponsableInscripcion`
--

DROP TABLE IF EXISTS `ResponsableInscripcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ResponsableInscripcion` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `DateModified` datetime(6) NOT NULL,
  `Value` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResponsableInscripcion`
--

LOCK TABLES `ResponsableInscripcion` WRITE;
/*!40000 ALTER TABLE `ResponsableInscripcion` DISABLE KEYS */;
/*!40000 ALTER TABLE `ResponsableInscripcion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RifaConfigs`
--

DROP TABLE IF EXISTS `RifaConfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RifaConfigs` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CompeticionId` int NOT NULL,
  `NombrePremio` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `DescripcionPremio` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PrecioTicket` decimal(10,2) NOT NULL,
  `TicketsTotal` int NOT NULL,
  `Activo` tinyint(1) NOT NULL,
  `FechaSorteo` datetime(6) DEFAULT NULL,
  `NumeroGanador` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `GanadorInscripcionId` int DEFAULT NULL,
  `GanadorConfirmado` tinyint(1) DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_RifaConfigs_CompeticionId` (`CompeticionId`),
  CONSTRAINT `FK_RifaConfigs_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RifaConfigs`
--

LOCK TABLES `RifaConfigs` WRITE;
/*!40000 ALTER TABLE `RifaConfigs` DISABLE KEYS */;
INSERT INTO `RifaConfigs` VALUES (1,1,'Premio sorpresa','Premio para el ganador de la rifa',5.00,100,0,NULL,NULL,NULL,0,'2026-05-17 18:01:01.535210','2026-05-17 18:01:01.535210'),(2,2,'Premio sorpresa','Premio para el ganador de la rifa',5.00,100,0,NULL,NULL,NULL,0,'2026-05-17 18:01:01.582339','2026-05-17 18:01:01.582339');
/*!40000 ALTER TABLE `RifaConfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RifaTickets`
--

DROP TABLE IF EXISTS `RifaTickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RifaTickets` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CompeticionId` int NOT NULL,
  `InscripcionId` int DEFAULT NULL,
  `NumeroTicket` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `StripePaymentId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BuyerEmail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BuyerNombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Confirmado` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_RifaTickets_CompeticionId_NumeroTicket` (`CompeticionId`,`NumeroTicket`),
  KEY `IX_RifaTickets_Confirmado` (`Confirmado`),
  KEY `IX_RifaTickets_InscripcionId` (`InscripcionId`),
  CONSTRAINT `FK_RifaTickets_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_RifaTickets_Inscripciones_InscripcionId` FOREIGN KEY (`InscripcionId`) REFERENCES `Inscripciones` (`Id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RifaTickets`
--

LOCK TABLES `RifaTickets` WRITE;
/*!40000 ALTER TABLE `RifaTickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `RifaTickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SchedulePublishedConfig`
--

DROP TABLE IF EXISTS `SchedulePublishedConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchedulePublishedConfig` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `DateModified` datetime(6) NOT NULL,
  `Value` tinyint(1) NOT NULL,
  `CompeticionId` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_SchedulePublishedConfig_CompeticionId` (`CompeticionId`),
  CONSTRAINT `FK_SchedulePublishedConfig_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SchedulePublishedConfig`
--

LOCK TABLES `SchedulePublishedConfig` WRITE;
/*!40000 ALTER TABLE `SchedulePublishedConfig` DISABLE KEYS */;
INSERT INTO `SchedulePublishedConfig` VALUES (1,'2026-05-24 06:48:28.081994',0,2);
/*!40000 ALTER TABLE `SchedulePublishedConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Schedules`
--

DROP TABLE IF EXISTS `Schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Schedules` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `SexCategory` int NOT NULL,
  `WeightCategory` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Date` date NOT NULL,
  `StartTime` time(6) NOT NULL,
  `EndTime` time(6) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `CompeticionId` int DEFAULT NULL,
  `Activo` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `IX_Schedules_Date` (`Date`),
  KEY `IX_Schedules_SexCategory_WeightCategory` (`SexCategory`,`WeightCategory`),
  KEY `IX_Schedules_CompeticionId` (`CompeticionId`),
  CONSTRAINT `FK_Schedules_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Schedules`
--

LOCK TABLES `Schedules` WRITE;
/*!40000 ALTER TABLE `Schedules` DISABLE KEYS */;
INSERT INTO `Schedules` VALUES (1,0,'-59','2026-05-17','09:00:00.000000','10:00:00.000000','2026-05-17 21:12:55.177065','2026-05-17 21:12:55.177117',2,0),(2,1,'-43','2026-05-17','09:00:00.000000','10:00:00.000000','2026-05-17 21:13:06.757510','2026-05-17 21:13:06.757511',2,0),(3,1,'-47','2026-05-17','09:00:00.000000','10:00:00.000000','2026-05-17 21:23:24.526188','2026-05-17 21:23:24.526188',2,0),(4,1,'-52','2026-05-17','09:00:00.000000','10:00:00.000000','2026-05-17 21:23:28.271850','2026-05-17 21:23:28.271850',2,0),(5,1,'-57','2026-05-17','11:00:00.000000','12:00:00.000000','2026-05-17 21:23:36.418171','2026-05-17 21:23:36.418171',2,0);
/*!40000 ALTER TABLE `Schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StripeConfig`
--

DROP TABLE IF EXISTS `StripeConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `StripeConfig` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `SecretKey` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `PublishableKey` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `WebhookSecret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `CompeticionId` int DEFAULT NULL,
  `Activo` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `IX_StripeConfig_CompeticionId` (`CompeticionId`),
  CONSTRAINT `FK_StripeConfig_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StripeConfig`
--

LOCK TABLES `StripeConfig` WRITE;
/*!40000 ALTER TABLE `StripeConfig` DISABLE KEYS */;
INSERT INTO `StripeConfig` VALUES (1,'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','pk_live_51TaajRRiba9vq000UbRgbcRQ2gQek49il8iN51eNohMTmcUQNo3TjLUea4xQiTIeH6uy91bCJ5nHbfUp4iKFeedr00YYpu0IZF','whsec_FGxOinIUMUW9OxiGEPWhSOkWvLi4dRXb','2026-05-24 17:22:49.569871','2026-05-25 19:38:08.913300',2,1),(2,'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','pk_live_51TaajRRiba9vq000UbRgbcRQ2gQek49il8iN51eNohMTmcUQNo3TjLUea4xQiTIeH6uy91bCJ5nHbfUp4iKFeedr00YYpu0IZF','whsec_FGxOinIUMUW9OxiGEPWhSOkWvLi4dRXb','2026-05-29 16:09:39.000000','2026-05-29 16:09:39.000000',NULL,1);
/*!40000 ALTER TABLE `StripeConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TutorialInteractions`
--

DROP TABLE IF EXISTS `TutorialInteractions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TutorialInteractions` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `VideoId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Tipo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Contenido` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Autor` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SessionId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`Id`),
  KEY `IX_TutorialInteractions_VideoId` (`VideoId`),
  KEY `IX_TutorialInteractions_VideoId_Tipo` (`VideoId`,`Tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TutorialInteractions`
--

LOCK TABLES `TutorialInteractions` WRITE;
/*!40000 ALTER TABLE `TutorialInteractions` DISABLE KEYS */;
INSERT INTO `TutorialInteractions` VALUES (1,'video-0508','like',NULL,NULL,'deploy-smoke-20260517-2317','2026-05-17 23:17:31.779890'),(2,'deploy-smoke-20260517','comment','Smoke test 2026-05-17','Deploy smoke',NULL,'2026-05-17 23:17:54.991089'),(3,'video-0508','like',NULL,NULL,'159a0ab8-cf08-4c1a-a407-0c85febd97ea','2026-05-17 23:36:27.185796'),(4,'video-0513','like',NULL,NULL,'159a0ab8-cf08-4c1a-a407-0c85febd97ea','2026-05-17 23:36:32.906489'),(5,'video-0512','like',NULL,NULL,'159a0ab8-cf08-4c1a-a407-0c85febd97ea','2026-05-17 23:36:35.885164'),(6,'video-0509','like',NULL,NULL,'159a0ab8-cf08-4c1a-a407-0c85febd97ea','2026-05-17 23:36:37.564189'),(8,'video-0508','like',NULL,NULL,'cf30c0f6-0ecf-4b92-ac9a-224916da49cc','2026-05-22 09:21:43.578203'),(9,'video-0509','like',NULL,NULL,'cf30c0f6-0ecf-4b92-ac9a-224916da49cc','2026-05-22 09:21:47.578245'),(10,'video-0512','comment','Que guay!','Maria',NULL,'2026-05-22 09:22:03.697487'),(11,'video-0513','like',NULL,NULL,'a3e13d00-a624-4641-b5e3-4a4c51c1f6ec','2026-05-25 16:35:10.192741'),(12,'video-0512','like',NULL,NULL,'a3e13d00-a624-4641-b5e3-4a4c51c1f6ec','2026-05-25 16:35:11.981666'),(13,'video-0508','like',NULL,NULL,'a3e13d00-a624-4641-b5e3-4a4c51c1f6ec','2026-05-25 16:35:16.995197'),(16,'video-0512','like',NULL,NULL,'042daa82-bdee-4376-9cc7-a6ffe1827798','2026-06-01 19:54:21.587068'),(17,'video-0513','like',NULL,NULL,'042daa82-bdee-4376-9cc7-a6ffe1827798','2026-06-01 19:54:32.914205'),(18,'video-0509','like',NULL,NULL,'042daa82-bdee-4376-9cc7-a6ffe1827798','2026-06-01 19:54:52.171129');
/*!40000 ALTER TABLE `TutorialInteractions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UrlInscripcion`
--

DROP TABLE IF EXISTS `UrlInscripcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UrlInscripcion` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `DateModified` datetime(6) NOT NULL,
  `Url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UrlInscripcion`
--

LOCK TABLES `UrlInscripcion` WRITE;
/*!40000 ALTER TABLE `UrlInscripcion` DISABLE KEYS */;
/*!40000 ALTER TABLE `UrlInscripcion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuarios`
--

DROP TABLE IF EXISTS `Usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Usuarios` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `PasswordHash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `IsSuperadmin` tinyint(1) NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `LastLoginAt` datetime(6) DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `IsRoot` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Usuarios_Email` (`Email`),
  KEY `IX_Usuarios_IsSuperadmin` (`IsSuperadmin`),
  KEY `IX_Usuarios_IsRoot` (`IsRoot`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuarios`
--

LOCK TABLES `Usuarios` WRITE;
/*!40000 ALTER TABLE `Usuarios` DISABLE KEYS */;
INSERT INTO `Usuarios` VALUES (1,'admin@grplatform.com','9hJNGNwBFbuqa57u2gpkpQ==:GJ9f3qJ+nanmhbbbnKUMssF55nXdx+nGak7kdjoUc08=','Super Admin',1,1,'2026-05-24 11:10:25.558276','2026-05-17 18:01:01.324557','2026-05-24 11:10:25.558337',1),(2,'root@hotmail.com','mxA63s6IzxGE/N+qWFcsFA==:7pYvMsHtCWlJY0Cg/FR039Q5kP0tnFJNq/CGh92FaAc=','Root User',1,1,'2026-05-23 23:08:31.325896','2026-05-17 19:33:45.000000','2026-05-23 23:08:31.325945',1),(3,'nicogorra14@gmail.com','GdbH/O7aJX/Iaf9dMrhyPQ==:+kyJtLtAxJv+wSLg2pWfLbszTcNBITWan2jHc0M89fY=','Nico GR',0,1,'2026-06-01 20:39:03.287204','2026-05-17 22:13:40.506137','2026-06-01 20:39:03.287249',0),(4,'jaimebillanueba99@gmail.com','emF+kUluVdlpj+kd0X6JSQ==:DoO6XDyP1YILIcxBQxJzbCRDzAA+6gO3Bl+XW81uv6o=','Jaime Billanueba',0,1,'2026-06-02 18:32:14.901217','2026-05-17 22:14:45.832841','2026-06-02 18:32:14.901218',0);
/*!40000 ALTER TABLE `Usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UsuariosCompeticiones`
--

DROP TABLE IF EXISTS `UsuariosCompeticiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UsuariosCompeticiones` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UsuarioId` int NOT NULL,
  `CompeticionId` int NOT NULL,
  `Role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `InvitedByEmail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `InvitedAt` datetime(6) DEFAULT NULL,
  `InvitationAccepted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UsuariosCompeticiones_UsuarioId_CompeticionId` (`UsuarioId`,`CompeticionId`),
  KEY `IX_UsuariosCompeticiones_CompeticionId` (`CompeticionId`),
  CONSTRAINT `FK_UsuariosCompeticiones_Competiciones_CompeticionId` FOREIGN KEY (`CompeticionId`) REFERENCES `Competiciones` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_UsuariosCompeticiones_Usuarios_UsuarioId` FOREIGN KEY (`UsuarioId`) REFERENCES `Usuarios` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UsuariosCompeticiones`
--

LOCK TABLES `UsuariosCompeticiones` WRITE;
/*!40000 ALTER TABLE `UsuariosCompeticiones` DISABLE KEYS */;
INSERT INTO `UsuariosCompeticiones` VALUES (1,1,1,'admin','2026-05-17 18:01:01.444591',NULL,NULL,1),(2,1,2,'admin','2026-05-17 18:01:01.499494',NULL,NULL,1),(3,2,1,'root','2026-05-17 19:33:45.000000',NULL,NULL,1),(4,2,2,'root','2026-05-17 19:33:45.000000',NULL,NULL,1),(6,3,2,'admin','2026-05-17 22:13:40.516978','root@hotmail.com','2026-05-17 22:13:40.516868',0),(7,4,2,'admin','2026-05-17 22:14:45.834943','root@hotmail.com','2026-05-17 22:14:45.834943',0);
/*!40000 ALTER TABLE `UsuariosCompeticiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UsuariosPermissions`
--

DROP TABLE IF EXISTS `UsuariosPermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UsuariosPermissions` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UsuarioId` int NOT NULL,
  `PermissionKey` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Granted` tinyint(1) NOT NULL,
  `CompeticionId` int DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_UsuariosPermissions_UsuarioId_PermissionKey_CompeticionId` (`UsuarioId`,`PermissionKey`,`CompeticionId`),
  CONSTRAINT `FK_UsuariosPermissions_Usuarios_UsuarioId` FOREIGN KEY (`UsuarioId`) REFERENCES `Usuarios` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UsuariosPermissions`
--

LOCK TABLES `UsuariosPermissions` WRITE;
/*!40000 ALTER TABLE `UsuariosPermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `UsuariosPermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `__EFMigrationsHistory`
--

DROP TABLE IF EXISTS `__EFMigrationsHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `__EFMigrationsHistory` (
  `MigrationId` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ProductVersion` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`MigrationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__EFMigrationsHistory`
--

LOCK TABLES `__EFMigrationsHistory` WRITE;
/*!40000 ALTER TABLE `__EFMigrationsHistory` DISABLE KEYS */;
INSERT INTO `__EFMigrationsHistory` VALUES ('20260322202621_InitialCreate','8.0.2'),('20260329192155_AddAthletesAndSchedules','8.0.2'),('20260331210000_AddInscripcionConfigAndPreparada','8.0.2'),('20260402120000_AddParticipantRaffleFields','8.0.2'),('20260402180000_AddResponsableAndUrlInscripcionTables','8.0.2'),('20260402225041_AddInscritoStatus','8.0.2'),('20260402232938_AddSchedulePublishedConfigTable','8.0.2'),('20260402234423_AddParticipantStripeSessionIdAndDrawParticipantId','8.0.2'),('20260406000000_AddEmailConfig','8.0.2'),('20260407000000_AddStripeConfig','8.0.2'),('20260409001316_RemoveUniqueEmailAddCompositeIndex','8.0.2'),('20260409214049_AddRaffleConfig','8.0.2'),('20260410232749_AddRaffleProductsAndMethod','8.0.2'),('20260411134507_MigrateRaffleProductsToCDN','8.0.2'),('20260505220951_MultiTenant_Schema_Phase1','8.0.2'),('20260506123135_AddCompeticionContactFields','8.0.2'),('20260510151939_AddFerInscriptionFields','8.0.2'),('20260511144316_AddCompeticionIdToSchedulesAndHorariosReady','8.0.2'),('20260511154124_RemovePesoAproxFromInscripcion','8.0.2'),('20260511155300_AddCompeticionIdToEmailAndStripeConfig','8.0.2'),('20260512133825_AddLiftEntriesAndAthleteQr','8.0.2'),('20260514143307_AddQuierePeakProgram','8.0.2'),('20260514145353_RemoveUpsellPreparacion','8.0.2'),('20260514172329_AddLiftEntryInscripcion','8.0.2'),('20260514181358_AddJudgeVotes','8.0.2'),('20260517120000_AddUserRoleFlags','8.0.2'),('20260517133000_EnsureTutorialInteractionsSchema','8.0.2'),('20260523120000_AddCompetitionModules','8.0.2'),('20260524120000_AddInscripcionModalidad','8.0.2'),('20260524133000_AddInscriptionStripePaymentFlow','8.0.2'),('20260524143000_AddDiscountCoupons','8.0.2'),('20260601140828_AddReferralSystem','8.0.2'),('20260601154051_ReferralPolishAndTopeDrop','8.0.2');
/*!40000 ALTER TABLE `__EFMigrationsHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raffle_config_legacy`
--

DROP TABLE IF EXISTS `raffle_config_legacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `raffle_config_legacy` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) NOT NULL,
  `IsEnabled` tinyint(1) NOT NULL,
  `DisabledMessage` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `RaffleMethod` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raffle_config_legacy`
--

LOCK TABLES `raffle_config_legacy` WRITE;
/*!40000 ALTER TABLE `raffle_config_legacy` DISABLE KEYS */;
/*!40000 ALTER TABLE `raffle_config_legacy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'grcup'
--

--
-- Dumping routines for database 'grcup'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-02 18:42:52
